<?php
header('location:media.php?hal=home');
?>