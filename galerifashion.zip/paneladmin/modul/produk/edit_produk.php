<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div class="workplace">
            
            <div class="row-fluid">
                
                <div class="span12">
                  <div class="block-fluid">                        
                     <div class="head clearfix">
                        <div class="isw-favorite"></div>
                        <h1>WYSIWYG HTML Editor</h1>
                    </div>    
                      <div class="row-form clearfix">
                            <div class="span3">Input type text:</div>
                            <div class="span9"><input type="text" value="some text value..."/></div>
                        </div> 

                        <div class="row-form clearfix">
                            <div class="span3">Input type password:</div>
                            <div class="span9"><input type="password" value="123123123"/></div>
                        </div>                         

                        <div class="row-form clearfix">
                            <div class="span3">Readonly input:</div>
                            <div class="span9"><input type="text" value="readonly input field..." readonly/></div>                            
                        </div> 

                        <div class="row-form clearfix">
                            <div class="span3">Disabled input:</div>
                            <div class="span9"><input type="text" value="disabled input field..." disabled="disabled"/></div>
                        </div>                                       
                        
                        <div class="row-form clearfix">
                            <div class="span3">Placeholder:</div>
                            <div class="span9"><input type="text" placeholder="placeholder..."/></div>
                        </div>                                                               

                        <div class="row-form clearfix">
                            <div class="span3">Textarea field:</div>
                            <div class="span9"><textarea name="textarea">Some text in textarea field...</textarea></div>
                        </div>                        

                        <div class="row-form clearfix">
                            <div class="span3">Textarea placeholder:</div>
                            <div class="span9"><textarea name="textarea" placeholder="Textarea field placeholder..."></textarea></div>
                        </div>                                                
                        
                    </div>
                </div>
                
            </div>
            
            <div class="dr"><span></span></div>
</body>
</html>