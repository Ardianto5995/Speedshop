<div class="content">
  <div class="workplace">
    <div class="dr"><span></span></div>
            <div class="row-fluid">
                <div class="span6">
                     <div class="head clearfix">
                        <div class="isw-list"></div>
                        <h1>Ubah Password Admin</h1>
                    </div>
                    <div class="block-fluid">                        
                    <form method="post" action="modul/gantipassword/aksi_password.php">    
                        <div class="row-form clearfix">
                            <div class="span5">Masukkan Password Lama:</div>
                            <div class="span7">
                                <input type="text" name="pass_lama"/>
                            </div>
                        </div>                                            

                        <div class="row-form clearfix">
                            <div class="span5">Masukkan Password Baru:</div>
                            <div class="span7">
                                <input type="text" name="pass_baru"/>
                            </div>
                        </div>                         
                        
                        <div class="row-form clearfix">
                            <div class="span5">Masukkan Lagi Password Baru:</div>
                            <div class="span7">
                                <input type="text" name="pass_ulangi"/>
                            </div>
                        </div>           
                    </div>
                    <br />
                          <input type="submit" class='btn' value='Update'>
                </div>
            </div>
              </form>
      <div class="dr"><span></span></div>

</div>
</div>   
    