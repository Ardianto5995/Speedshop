// UK lang variables

tinyMCE.addToLang('nonbreaking',{
desc : 'Insert non-breaking space character'
});
